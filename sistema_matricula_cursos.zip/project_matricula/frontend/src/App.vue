<template>
  <div class="container">
    <div class="header">
      <h1>Sistema de Matrícula</h1>
      <p>Cursos Online de Tecnologia</p>
    </div>
    
    <FormularioMatricula />
  </div>
</template>

<script>
import FormularioMatricula from './components/FormularioMatricula.vue'

export default {
  name: 'App',
  components: {
    FormularioMatricula
  }
}
</script>

