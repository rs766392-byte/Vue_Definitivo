<template>
  <div class="card">
    <!-- Mensagem de sucesso -->
    <div v-if="mensagemSucesso" class="success">
      {{ mensagemSucesso }}
    </div>

    <!-- Formulário de matrícula -->
    <form @submit.prevent="realizarMatricula" v-if="!matriculaRealizada">
      <h2 style="margin-bottom: 25px; color: #667eea; text-align: center;">
        Realize sua Matrícula
      </h2>

      <!-- Campo Nome Completo -->
      <div class="form-group">
        <label for="nomeCompleto">Nome Completo *</label>
        <input
          type="text"
          id="nomeCompleto"
          v-model="formulario.nomeCompleto"
          :class="{ 'error-border': erros.nomeCompleto }"
          placeholder="Digite seu nome completo"
          @input="validarCampo('nomeCompleto')"
        />
        <div v-if="erros.nomeCompleto" class="error">
          {{ erros.nomeCompleto }}
        </div>
      </div>

      <!-- Campo Email -->
      <div class="form-group">
        <label for="email">Email *</label>
        <input
          type="email"
          id="email"
          v-model="formulario.email"
          :class="{ 'error-border': erros.email }"
          placeholder="Digite seu email"
          @input="validarCampo('email')"
        />
        <div v-if="erros.email" class="error">
          {{ erros.email }}
        </div>
      </div>

      <!-- Campo Curso -->
      <div class="form-group">
        <label for="curso">Curso *</label>
        <select
          id="curso"
          v-model="formulario.cursoId"
          :class="{ 'error-border': erros.cursoId }"
          @change="validarCampo('cursoId')"
        >
          <option value="">Selecione um curso</option>
          <option
            v-for="curso in cursos"
            :key="curso.id"
            :value="curso.id"
          >
            {{ curso.nome }}
          </option>
        </select>
        <div v-if="erros.cursoId" class="error">
          {{ erros.cursoId }}
        </div>
      </div>

      <!-- Informações do curso selecionado -->
      <div v-if="cursoSelecionado" class="curso-info">
        <h4>{{ cursoSelecionado.nome }}</h4>
        <p>{{ cursoSelecionado.descricao }}</p>
        <p><strong>Duração:</strong> {{ cursoSelecionado.duracao }}</p>
        <p class="preco">R$ {{ cursoSelecionado.preco.toFixed(2).replace('.', ',') }}</p>
      </div>

      <!-- Botão de envio -->
      <button
        type="submit"
        class="btn"
        :disabled="carregando || !formularioValido"
      >
        <span v-if="carregando">Processando...</span>
        <span v-else>Realizar Matrícula</span>
      </button>

      <!-- Mensagens de erro gerais -->
      <div v-if="erroGeral" class="error" style="text-align: center; margin-top: 15px;">
        {{ erroGeral }}
      </div>
    </form>

    <!-- Loading -->
    <div v-if="carregandoCursos" class="loading">
      Carregando cursos disponíveis...
    </div>
  </div>
</template>

<script>
export default {
  name: 'FormularioMatricula',
  data() {
    return {
      // Estado do formulário
      formulario: {
        nomeCompleto: '',
        email: '',
        cursoId: ''
      },
      
      // Lista de cursos
      cursos: [],
      
      // Estados de carregamento
      carregando: false,
      carregandoCursos: true,
      
      // Estados de sucesso/erro
      matriculaRealizada: false,
      mensagemSucesso: '',
      erroGeral: '',
      
      // Validações
      erros: {
        nomeCompleto: '',
        email: '',
        cursoId: ''
      }
    }
  },
  
  computed: {
    // Curso selecionado para exibir informações
    cursoSelecionado() {
      if (!this.formulario.cursoId) return null
      return this.cursos.find(curso => curso.id === parseInt(this.formulario.cursoId))
    },
    
    // Verifica se o formulário está válido
    formularioValido() {
      return this.formulario.nomeCompleto.trim().length >= 2 &&
             this.validarEmail(this.formulario.email) &&
             this.formulario.cursoId !== '' &&
             Object.values(this.erros).every(erro => erro === '')
    }
  },
  
  mounted() {
    this.carregarCursos()
  },
  
  methods: {
    // Carregar lista de cursos da API
    async carregarCursos() {
      try {
        this.carregandoCursos = true
        const response = await fetch('http://localhost:3001/cursos')
        const data = await response.json()
        
        if (data.success) {
          this.cursos = data.data
        } else {
          this.erroGeral = 'Erro ao carregar cursos disponíveis'
        }
      } catch (error) {
        console.error('Erro ao carregar cursos:', error)
        this.erroGeral = 'Erro de conexão. Verifique se o servidor está rodando.'
      } finally {
        this.carregandoCursos = false
      }
    },
    
    // Validar campo específico
    validarCampo(campo) {
      switch (campo) {
        case 'nomeCompleto':
          if (!this.formulario.nomeCompleto.trim()) {
            this.erros.nomeCompleto = 'Nome completo é obrigatório'
          } else if (this.formulario.nomeCompleto.trim().length < 2) {
            this.erros.nomeCompleto = 'Nome deve ter pelo menos 2 caracteres'
          } else {
            this.erros.nomeCompleto = ''
          }
          break
          
        case 'email':
          if (!this.formulario.email.trim()) {
            this.erros.email = 'Email é obrigatório'
          } else if (!this.validarEmail(this.formulario.email)) {
            this.erros.email = 'Email deve ter um formato válido'
          } else {
            this.erros.email = ''
          }
          break
          
        case 'cursoId':
          if (!this.formulario.cursoId) {
            this.erros.cursoId = 'Selecione um curso'
          } else {
            this.erros.cursoId = ''
          }
          break
      }
    },
    
    // Validar formato do email
    validarEmail(email) {
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      return regex.test(email)
    },
    
    // Realizar matrícula
    async realizarMatricula() {
      // Validar todos os campos
      this.validarCampo('nomeCompleto')
      this.validarCampo('email')
      this.validarCampo('cursoId')
      
      // Se há erros, não prosseguir
      if (!this.formularioValido) {
        return
      }
      
      try {
        this.carregando = true
        this.erroGeral = ''
        
        const dadosMatricula = {
          nomeCompleto: this.formulario.nomeCompleto.trim(),
          email: this.formulario.email.trim().toLowerCase(),
          cursoId: parseInt(this.formulario.cursoId)
        }
        
        const response = await fetch('http://localhost:3001/matricula', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(dadosMatricula)
        })
        
        const data = await response.json()
        
        if (data.success) {
          this.matriculaRealizada = true
          this.mensagemSucesso = `Parabéns! Sua matrícula no curso "${data.data.curso.nome}" foi realizada com sucesso!`
        } else {
          if (data.errors && data.errors.length > 0) {
            this.erroGeral = data.errors.join(', ')
          } else {
            this.erroGeral = data.message || 'Erro ao realizar matrícula'
          }
        }
      } catch (error) {
        console.error('Erro ao realizar matrícula:', error)
        this.erroGeral = 'Erro de conexão. Verifique se o servidor está rodando.'
      } finally {
        this.carregando = false
      }
    }
  }
}
</script>

<style scoped>
.error-border {
  border-color: #e74c3c !important;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none !important;
}

.curso-info {
  animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>

