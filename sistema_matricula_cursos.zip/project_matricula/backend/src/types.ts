export interface Curso {
  id: number;
  nome: string;
  descricao: string;
  preco: number;
  duracao: string;
}

export interface DadosMatricula {
  nomeCompleto: string;
  email: string;
  cursoId: number;
}

export interface MatriculaResponse {
  id: number;
  nomeCompleto: string;
  email: string;
  curso: Curso;
  dataMatricula: string;
}

