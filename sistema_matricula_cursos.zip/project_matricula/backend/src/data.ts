import { Curso, MatriculaResponse } from './types';

export const cursos: Curso[] = [
  {
    id: 1,
    nome: "Desenvolvimento Web Frontend",
    descricao: "Aprenda HTML, CSS, JavaScript e frameworks modernos",
    preco: 299.99,
    duracao: "40 horas"
  },
  {
    id: 2,
    nome: "Backend com Node.js",
    descricao: "Desenvolvimento de APIs e serviços com Node.js e Express",
    preco: 349.99,
    duracao: "50 horas"
  },
  {
    id: 3,
    nome: "Banco de Dados SQL",
    descricao: "Fundamentos de SQL e modelagem de dados",
    preco: 199.99,
    duracao: "30 horas"
  },
  {
    id: 4,
    nome: "React Avançado",
    descricao: "Desenvolvimento de aplicações complexas com React",
    preco: 399.99,
    duracao: "60 horas"
  },
  {
    id: 5,
    nome: "DevOps e Deploy",
    descricao: "Automatização, CI/CD e deploy de aplicações",
    preco: 449.99,
    duracao: "45 horas"
  }
];

// Simulação de banco de dados em memória
export const matriculas: MatriculaResponse[] = [];

