import express, { Request, Response } from 'express';
import { DadosMatricula, MatriculaResponse } from './types';
import { cursos, matriculas } from './data';

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware para parsing JSON
app.use(express.json());

// Middleware para CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Rota GET /cursos - Retorna lista de cursos disponíveis
app.get('/cursos', (req: Request, res: Response) => {
  try {
    res.status(200).json({
      success: true,
      data: cursos,
      message: 'Cursos recuperados com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// Função para validar dados de matrícula
function validarDadosMatricula(dados: any): { valido: boolean; erros: string[] } {
  const erros: string[] = [];

  if (!dados.nomeCompleto || typeof dados.nomeCompleto !== 'string' || dados.nomeCompleto.trim().length < 2) {
    erros.push('Nome completo é obrigatório e deve ter pelo menos 2 caracteres');
  }

  if (!dados.email || typeof dados.email !== 'string') {
    erros.push('Email é obrigatório');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(dados.email)) {
      erros.push('Email deve ter um formato válido');
    }
  }

  if (!dados.cursoId || typeof dados.cursoId !== 'number') {
    erros.push('ID do curso é obrigatório e deve ser um número');
  } else {
    const cursoExiste = cursos.find(curso => curso.id === dados.cursoId);
    if (!cursoExiste) {
      erros.push('Curso selecionado não existe');
    }
  }

  return {
    valido: erros.length === 0,
    erros
  };
}

// Rota POST /matricula - Recebe dados do aluno e realiza matrícula
app.post('/matricula', (req: Request, res: Response) => {
  try {
    const dadosMatricula: DadosMatricula = req.body;
    
    // Validar dados recebidos
    const validacao = validarDadosMatricula(dadosMatricula);
    
    if (!validacao.valido) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: validacao.erros
      });
    }

    // Verificar se o email já está cadastrado
    const emailJaCadastrado = matriculas.find(m => m.email === dadosMatricula.email);
    if (emailJaCadastrado) {
      return res.status(400).json({
        success: false,
        message: 'Este email já está cadastrado em nosso sistema'
      });
    }

    // Buscar dados do curso
    const curso = cursos.find(c => c.id === dadosMatricula.cursoId);
    
    if (!curso) {
      return res.status(400).json({
        success: false,
        message: 'Curso não encontrado'
      });
    }

    // Criar nova matrícula
    const novaMatricula: MatriculaResponse = {
      id: matriculas.length + 1,
      nomeCompleto: dadosMatricula.nomeCompleto.trim(),
      email: dadosMatricula.email.toLowerCase().trim(),
      curso: curso,
      dataMatricula: new Date().toISOString()
    };

    // Adicionar à lista de matrículas
    matriculas.push(novaMatricula);

    // Retornar sucesso
    res.status(201).json({
      success: true,
      data: novaMatricula,
      message: 'Matrícula realizada com sucesso!'
    });

  } catch (error) {
    console.error('Erro ao processar matrícula:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// Rota para verificar se o servidor está funcionando
app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({
    success: true,
    message: 'Servidor funcionando corretamente',
    timestamp: new Date().toISOString()
  });
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando na porta ${PORT}`);
  console.log(`Acesse: http://localhost:${PORT}`);
});

export default app;

